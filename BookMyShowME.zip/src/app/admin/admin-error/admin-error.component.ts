import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-error',
  templateUrl: './admin-error.component.html',
  styleUrls: ['./admin-error.component.css']
})
export class AdminErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
