import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-booked-tickets',
  templateUrl: './view-booked-tickets.component.html',
  styleUrls: ['./view-booked-tickets.component.css']
})
export class ViewBookedTicketsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
