import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movieslist',
  templateUrl: './movieslist.component.html',
  styleUrls: ['./movieslist.component.css']
})
export class MovieslistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
