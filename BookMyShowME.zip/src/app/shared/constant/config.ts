export const APP_CONFIG = {
  //http://localhost:8912/movie
    API_URL: "http://localhost:8912/",
    //API_URL: "https://api.rightmedicaladvice.com/api/",
    // API_URL: "http://127.0.0.1:8000/api/",
    IMAGE_URL: "https://api.rightmedicaladvice.com/storage/app/",
    CURRUNCY: "Rs. "
  }
  